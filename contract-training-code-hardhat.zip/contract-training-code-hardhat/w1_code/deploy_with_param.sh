

export HARDHAT_NETWORK='dev'

node scripts/deploy_by_param.js 10