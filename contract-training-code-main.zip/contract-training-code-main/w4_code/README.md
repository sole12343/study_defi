# LooneySwap
A rudimentary implementation of uniswap for educational purposes. You'd be crazy to actually use this.

## Guide
Read the guide here: [Uniswap from scratch](https://monokh.com/posts/uniswap-from-scratch)

## Run tests
```
npm install
npx hardhat compile
npx hardhat test
```
